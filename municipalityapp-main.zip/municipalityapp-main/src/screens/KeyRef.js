import React, { memo } from 'react'
import { View, Text } from 'react-native'
const KeyRef = memo(() => {
    return (
        <View>
            <Text>ENTER KEY REF</Text>
        </View>
    )
})

export default KeyRef